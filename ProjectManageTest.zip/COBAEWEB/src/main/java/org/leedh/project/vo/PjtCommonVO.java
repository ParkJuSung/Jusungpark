package org.leedh.project.vo;

import lombok.Data;

@Data
public class PjtCommonVO {

    private String pjtC;
    private String PjtDivC;
    private String PjtStC;
    private String PjtOrgC;

}
