PJTMGR 포커스리더 프로젝트 매니저 
