package org.leedh.user.vo;

import lombok.Data;

@Data
public class AuthVO {

    private String empEmail;
    private String empNm;
    private int grade;

}
